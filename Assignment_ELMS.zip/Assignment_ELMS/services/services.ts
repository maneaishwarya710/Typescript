import { LeaveRepository } from '../repositories/leaveRepo';
import { Leave } from '../models/leaveModel';
class LeaveService {
    private leaveRepository = new LeaveRepository();

    async applyLeave(leave: Leave): Promise<Leave> {
        return await this.leaveRepository.createLeave(leave);
    }

    async getLeaveHistory(employeeId: number): Promise<Leave[]> {
        return await this.leaveRepository.getLeavesByEmployeeId(employeeId);
    }

    async getPendingLeaves(): Promise<Leave[]> {
        return await this.leaveRepository.getPendingLeaves();
    }

    async approveLeave(leaveId: number): Promise<void> {
        await this.leaveRepository.updateLeaveStatus(leaveId, 'Approved');
    }

    async rejectLeave(leaveId: number): Promise<void> {
        await this.leaveRepository.updateLeaveStatus(leaveId, 'Rejected');
    }

    async getAllLeaves(): Promise<Leave[]> {
        return await this.leaveRepository.getAllLeaves();
    }
}

export { LeaveService };
