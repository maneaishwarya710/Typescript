import { Request, Response } from 'express';
import { LeaveService } from '../services/services';
import { Leave } from '../models/leaveModel';

const leaveService = new LeaveService();

class LeaveController {
    async applyLeave(req: Request, res: Response): Promise<void> {
        try {
            const leave = new Leave(0, req.body.employeeId, new Date(req.body.startDate), new Date(req.body.endDate), req.body.leaveType, 'Pending', req.body.reason);
            const newLeave = await leaveService.applyLeave(leave);
            res.status(201).json(newLeave);
        } catch (error) {
            res.status(500).json({ message: 'Error applying leave', error });
        }
    }

    async getLeaveHistory(req: Request, res: Response): Promise<void> {
        try {
            const employeeId = Number(req.params.employeeId);
            const leaves = await leaveService.getLeaveHistory(employeeId);
            res.status(200).json(leaves);
        } catch (error) {
            res.status(500).json({ message: 'Error fetching leave history', error });
        }
    }

    async getPendingLeaves(req: Request, res: Response): Promise<void> {
        try {
            const leaves = await leaveService.getPendingLeaves();
            res.status(200).json(leaves);
        } catch (error) {
            res.status(500).json({ message: 'Error fetching pending leaves', error });
        }
    }

    async approveLeave(req: Request, res: Response): Promise<void> {
        try {
            const leaveId = Number(req.params.leaveId);
            await leaveService.approveLeave(leaveId);
            res.status(200).json({ message: 'Leave approved' });
        } catch (error) {
            res.status(500).json({ message: 'Error approving leave', error });
        }
    }

    async rejectLeave(req: Request, res: Response): Promise<void> {
        try {
            const leaveId = Number(req.params.leaveId);
            await leaveService.rejectLeave(leaveId);
            res.status(200).json({ message: 'Leave rejected' });
        } catch (error) {
            res.status(500).json({ message: 'Error rejecting leave', error });
        }
    }

    async getAllLeaves(req: Request, res: Response): Promise<void> {
        try {
            const leaves = await leaveService.getAllLeaves();
            res.status(200).json(leaves);
        } catch (error) {
            res.status(500).json({ message: 'Error fetching leave reports', error });
        }
    }
}

export { LeaveController };
