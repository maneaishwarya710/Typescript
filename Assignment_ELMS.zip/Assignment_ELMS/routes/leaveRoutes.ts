import { Router } from 'express';
import { LeaveController } from '../controllers/leaveController';
const router = Router();
const leaveController = new LeaveController();

router.post('/leaves', (req, res) => leaveController.applyLeave(req, res));
router.get('/leaves/:employeeId', (req, res) => leaveController.getLeaveHistory(req, res));
router.get('/leaves/pending', (req, res) => leaveController.getPendingLeaves(req, res));
router.put('/leaves/:leaveId/approve', (req, res) => leaveController.approveLeave(req, res));
router.put('/leaves/:leaveId/reject', (req, res) => leaveController.rejectLeave(req, res));
router.get('/leaves/report', (req, res) => leaveController.getAllLeaves(req, res));

export default router;
