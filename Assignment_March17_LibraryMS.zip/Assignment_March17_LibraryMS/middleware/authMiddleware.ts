import { NextFunction, Response,Request } from "express";
import jwt,{JwtPayload} from "jsonwebtoken";
import { AuthRequest } from "../types/authRequest";
import { AuthService } from "../Services/authService";

const secretKey = "468ee09c42fcbb0fed48f1db12edf3c48e99fd4b7dbf1c97c32f89d165aae5db";

const authService = new AuthService()


interface Decoded{
    username:string,
    role:string,
    iat:number,
    exp:number
}

 const authenticateUser = async(
  req: AuthRequest, // Custom request type
  res: Response,
  next: NextFunction
)  => {
  // Corrected: Use req.headers.get("authorization") OR type assertion
//   const authHeader = (req.headers as unknown as Record<string, string>)["authorization"];
  if (!req.header("Authorization") || !req.header("Authorization")?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Access denied. No token provided." });
    return;
  }

  const token = req.header("Authorization")?.split(" ")[1];
  try {
    const decoded = jwt.verify(token!, secretKey) as JwtPayload & Decoded;

    const freshUser = await authService.getUserByUsername(decoded.username);

    (req as AuthRequest).user = freshUser; // Attach decoded user to request
    next();
  } catch (error) {
    res.status(401).json({ error: "Invalid token." });
    return;
  }
};



const roleBasedAuth = (roles:string[])=>{
    return (req:Request,res:Response,next:NextFunction)=>{
        const user = (req as AuthRequest).user;

        if(!roles.includes(user.role)){
            res.status(404).json({
                message:"You dont have permission to perform this action"
            })
            return;
        }
        next()
    }
}

export  {authenticateUser,roleBasedAuth}