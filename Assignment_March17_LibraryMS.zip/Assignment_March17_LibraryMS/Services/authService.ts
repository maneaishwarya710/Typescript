import { UserRepository } from "../Repositories/userRepo";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const userRepository = new UserRepository();
const SECRET_KEY = "secretKey";

class AuthService {
    static async createUser(username: string, password: string, role: string) {
        const hashedPassword = await bcrypt.hash(password, 10);
        return await userRepository.createUser(username, hashedPassword, role);
    }

    static async loginUser(username: string, password: string) {
        const user = await userRepository.getUserByUsername(username);
        if (!user) throw new Error("User not found");

        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) throw new Error("Invalid credentials");

        const token = jwt.sign({ username: user.username, role: user.role }, SECRET_KEY, { expiresIn: "1h" });
        return { user, token };
    }
}

export { AuthService };