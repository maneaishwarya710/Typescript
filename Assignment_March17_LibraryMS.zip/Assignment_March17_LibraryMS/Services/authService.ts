import { UserRepository } from "../Repositories/userRepo";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const userRepository = new UserRepository();
const SECRET_KEY = "468ee09c42fcbb0fed48f1db12edf3c48e99fd4b7dbf1c97c32f89d165aae5db";

class AuthService {
    static async createUser(username: string, password: string, role: string) {
        const hashedPassword = await bcrypt.hash(password, 10);
        return await userRepository.createUser(username, hashedPassword, role);
    }

    static async loginUser(username: string, password: string) {
        const user = await userRepository.getUserByUsername(username);
        if (!user) throw new Error("User not found");

        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) throw new Error("Invalid credentials");

        const token = jwt.sign({ username: user.username, role: user.role }, SECRET_KEY, { expiresIn: "1h" });
        return { user, token };
    }

    async getUserByUsername(username:string){
        return await userRepository.getUserByUsername(username)
    }
}

export { AuthService };