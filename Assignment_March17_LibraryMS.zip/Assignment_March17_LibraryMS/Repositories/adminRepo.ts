import { poolPromise } from '../config/database';
import { User } from '../models/user.model';
import { Book } from '../models/book.model';

class AdminRepository {
    async getAllBooks(): Promise<Book[]> {
        const pool = await poolPromise;
        if (!pool) throw new Error("DB connection failed");
        
        const result = await pool.request().query("SELECT * FROM LibBook");
        return result.recordset.map((row: { id: number; title: string;  author: string, isbn: string, availableCopies:number}) => new Book(row.id, row.title, row.author, row.isbn, row.availableCopies));
    }

    async addBook(book: Book): Promise<Book> {
        const pool = await poolPromise;
        if (!pool) throw new Error("DB connection failed");

        const result = await pool.request()
            .input('id', book.id)
            .input('title', book.title)
            .input('author', book.author)
            .input('isbn', book.isbn)
            .input('availableCopies', book.availableCopies)
            .query("INSERT INTO LibBook (title, author, isbn, availableCopies) VALUES (@title, @author, @isbn, @availableCopies); SELECT SCOPE_IDENTITY() AS id;");
        book.id = result.recordset[0].id;
        return book;
    }

    async updateBook(id: number, availableCopies: number): Promise<void> {
        const pool = await poolPromise;
        if (!pool) throw new Error("DB connection failed");

        await pool.request()
            .input('id', id)
            .input('availableCopies', availableCopies)
            .query("UPDATE LibBook SET availableCopies = @availableCopies WHERE id = @id");
    }

    // async deleteBook(id: number): Promise<boolean> {
    //     const pool = await poolPromise;
    //     if (!pool) throw new Error("DB connection failed");

    //     const result = await pool.request()
    //         .input('id', id)
    //         .query("DELETE FROM LibBook WHERE id = @id");
    //     return result.rowsAffected[0] > 0;
    // }

    async deleteBook(id: number): Promise<boolean> {
        try {
            const pool = await poolPromise;
            if (!pool) throw new Error("DB connection failed");
    
            const result = await pool.request()
                .input('id', id)
                .query("DELETE FROM LibBook WHERE id = @id");
    
            return result.rowsAffected[0] > 0;
        } catch (error) {
            console.error("Error deleting book:", error);
            return false;
        }
    }
}

export { AdminRepository };