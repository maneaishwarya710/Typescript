import { poolPromise } from '../config/database';
import { User } from '../models/user.model';
import { Book } from '../models/book.model';
import sql from 'mssql';

class UserRepository {
    async createUser(username: string, password: string, role: string) {
        const pool = await poolPromise;
        if (!pool) throw new Error("DB connection failed");

        const result = await pool.request()
            .input("username", sql.VarChar, username)
            .input("password", sql.VarChar, password)
            .input("role", sql.VarChar, role)
            .query("INSERT INTO LibUser (username, password, role) VALUES (@username, @password, @role)");
        
        return result;
    }

    async getUserByUsername(username: string): Promise<User | null> {
        const pool = await poolPromise;
        if (!pool) throw new Error("DB connection failed");

        const result = await pool.request()
            .input('username', sql.VarChar, username)
            .query("SELECT * FROM LibUser WHERE username = @username");

        if (result.recordset.length > 0) {
            const row = result.recordset[0];
            return new User(row.id, row.username, row.password, row.role);
        } else {
            return null;
        }
    }
}

export { UserRepository };