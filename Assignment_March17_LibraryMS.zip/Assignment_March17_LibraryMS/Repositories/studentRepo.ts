import { poolPromise } from '../config/database';
import { User } from '../models/user.model';
import { Book } from '../models/book.model';
import sql from 'mssql';
import { BorrowedBooks } from '../models/borrowedBooks';

class StudentRepository {

    //search book by name
    async searchBook(title:string) {
        const pool = await poolPromise;
        if (!pool) throw new Error("DB connection failed");

        const result = await pool.request()
            .input('title', sql.VarChar, title)
            .query("SELECT * FROM LibBook WHERE title = @title");
        
        return result;
    }

    //View all books
    async viewBook(): Promise<Book[] | null> {
        try {
            const pool = await poolPromise;
            if (!pool) throw new Error("DB connection failed");
    
            const result = await pool.request()
                .query("SELECT * FROM LibBook");
    
            return result.recordset;
        } catch (error) {
            console.error("Error viewing books:", error);
            return null;
        }
    }

    //borrow Book
    async borrowBook(title:string):Promise<BorrowedBooks| null>{
        const pool=await poolPromise;
        if(!pool) throw new Error("DB Connection Failed!");

        const bookResult=await sql.query`select availableCopies from LibBook where title=@title`;
        const book=bookResult.recordset[0];
        
        if(!book || book.availableCopies<=0){
            throw new Error("Book is not available right now");
        }

        //update book table and reduce number of available copies
        await sql.query`update LibBook set availableCopies=availableCopies-1 where title=@title `;

        //insert record into borrowed book table
        await sql.query`insert into BorrowedBooks(userId, bookId, title, BorrowedDate, returnDate) values()`;
    }




    async getUserByUsername(username: string): Promise<User | null> {
        const pool = await poolPromise;
        if (!pool) throw new Error("DB connection failed");



        const result = await pool.request()
            .input('username', sql.VarChar, username)
            .query("SELECT * FROM LibUser WHERE username = @username");

        if (result.recordset.length > 0) {
            const row = result.recordset[0];
            return new User(row.id, row.username, row.password, row.role);
        } else {
            return null;
        }
    }
}

export { UserRepository };