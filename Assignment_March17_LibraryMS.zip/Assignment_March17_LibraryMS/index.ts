import express from 'express';
import { poolPromise } from './config/database';
import router from './routes/adminRoutes';
import adminRoutes from './routes/adminRoutes';
import { authRouter } from './routes/authRoute';
import { AuthRequest } from './types/authRequest';

const app = express();
const PORT = process.env.PORT || 3100;

// Middleware
app.use(express.json());

app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/', adminRoutes);
app.use("/auth", authRouter);

// Test database connection
poolPromise.then(() => {
    app.listen(PORT, () => {
        console.log(`Server is running on port ${PORT}`);
    });
}).catch((error: any) => {
    console.error('Unable to connect to the database:', error);
});

export default app;