import { Router } from 'express';
import { AdminController } from '../controllers/AdminController';
import { authenticateUser } from '../middleware/authMiddleware';
const router = Router();
const adminController = new AdminController();

router.post('/books', authenticateUser, (req, res) => adminController.addBook(req, res));
router.put('/books/:id/delete', (req, res) => adminController.deleteBook(req, res));
router.put('/books/:id/update', (req, res) => adminController.updateBook(req, res));

export default router;