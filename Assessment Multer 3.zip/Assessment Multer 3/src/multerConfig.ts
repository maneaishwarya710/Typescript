import multer from "multer";
import { Request } from "express";
import path from "path";

// Define storage options

const storage=multer.diskStorage({
  destination:(req:Request, file:Express.Multer.File, cb:(error:Error|null, destination:string)=>void)=>{
    cb(null, "uploads/");
  },
  filename:(req:Request, file:Express.Multer.File, cb:(error:Error|null, filename:string)=>void)=>{
    cb(null, `${Date.now()}-${file.originalname}`)
  }
});

// Create the multer instance
const upload=multer({
  storage:storage,
  limits:{fileSize:1024*1024*50}
});

export default upload;